import React, { useState, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './Components/Header';
import Home from './Components/Home';
import { Store } from './Components/Store';
import About from './Components/About';
import Cart from './Components/Cart';
import Footer from './Components/Footer';
import { CartProvider } from './Components/CartContext';
import ContactUs from './Components/ContactUs';
import ProductPage from './Components/ProductPage';
import AuthForm from './Components/AuthForm';
import Profile from './Components/Profile';
import { AuthContext } from './Components/auth-context';
import { EmailProvider } from './Components/EmailContext';

import './App.css';

const App = () => {
  const [cart, setCart] = useState([]);
  const { isLoggedIn } = useContext(AuthContext);
  const addToCart = (product) => {
    const existingProduct = cart.find((item) => item.id === product.id);
    if (existingProduct) {
      const updatedCart = cart.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      );
      setCart(updatedCart);
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (productId) => {
    const updatedCart = cart.filter((item) => item.id !== productId);
    setCart(updatedCart);
  };

  const getCartCount = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };


  return (
    <Router>
      <EmailProvider>


        <CartProvider value={{ cart, addToCart, removeFromCart, getCartCount }}>
          <div>
            <Header />
            <h2 className="store__generics">The Generics</h2>
            <Routes>
              <Route
                path="/"
                element={isLoggedIn ? <Home /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/store"
                element={isLoggedIn ? <Store /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/about"
                element={isLoggedIn ? <About /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/contact"
                element={isLoggedIn ? <ContactUs /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/product/:productId"
                element={isLoggedIn ? <ProductPage /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/cart"
                element={isLoggedIn ? <Cart /> : <Navigate to="/login" replace />}
              />
              <Route
                path="/login"
                element={!isLoggedIn ? <AuthForm /> : <Navigate to="/" replace />}
              />
              <Route
                path="/profile"
                element={isLoggedIn ? <Profile /> : <Navigate to="/login" replace />}
              />
            </Routes>
            <Footer />
          </div>
        </CartProvider>
      </EmailProvider>

    </Router>
  );
};

export default App;
