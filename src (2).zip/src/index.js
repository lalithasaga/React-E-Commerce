import React from 'react';
import { createRoot } from 'react-dom';
import './index.css';
import App from './App';
import { AuthContextProvider } from './Components/auth-context';
import { EmailProvider } from './Components/EmailContext';

createRoot(document.getElementById('root')).render(
  <AuthContextProvider>
    <EmailProvider>
      <React.StrictMode>
        <App />
      </React.StrictMode>
    </EmailProvider>
  </AuthContextProvider>
);
