import React, { useState, useContext, useEffect } from 'react';
import { AuthContext } from './auth-context';

const CartContext = React.createContext();

const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const { userId } = useContext(AuthContext); // Retrieve the userId from the AuthContext

  useEffect(() => {
    if (userId) {
      // Load cart data for the logged-in user
      // Replace this with your actual code to fetch cart data from a server or localStorage
      const cartData = loadCartData(userId);
      setCart(cartData);
    }
  }, [userId]);

  const addToCart = (product) => {
    const existingProduct = cart.find((item) => item.id === product.id && item.userId === userId);
    if (existingProduct) {
      const updatedCart = cart.map((item) =>
        item.id === product.id && item.userId === userId ? { ...item, quantity: item.quantity + 1 } : item
      );
      setCart(updatedCart);
    } else {
      setCart([...cart, { ...product, quantity: 1, userId }]);
    }
  };

  const removeFromCart = (productId) => {
    const updatedCart = cart.filter((item) => item.id !== productId);
    setCart(updatedCart);
  };

  const getCartCount = () => {
    return cart.reduce((total, item) => {
      if (item.userId === userId) {
        return total + item.quantity;
      }
      return total;
    }, 0);
  };

  // Replace this function with your actual implementation to load cart data
  const loadCartData = (userId) => {
    // Example: Load cart data from localStorage
    const cartData = localStorage.getItem(`cartData_${userId}`);
    return cartData ? JSON.parse(cartData) : [];
  };

  // Replace this function with your actual implementation to save cart data
  const saveCartData = (userId, cartData) => {
    // Example: Save cart data to localStorage
    localStorage.setItem(`cartData_${userId}`, JSON.stringify(cartData));
  };

  // Save cart data whenever the cart changes
  useEffect(() => {
    if (userId) {
      saveCartData(userId, cart);
    }
  }, [userId, cart]);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, getCartCount, userId }}>
      {children}
    </CartContext.Provider>
  );
};

export { CartContext, CartProvider };
