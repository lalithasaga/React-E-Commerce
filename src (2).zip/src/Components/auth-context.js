import React, { useState, useEffect } from 'react';

export const AuthContext = React.createContext({
  token: '',
  isLoggedIn: false,
  userId: '',
  login: (token, userId) => { },
  logout: () => { },
});

export const AuthContextProvider = (props) => {
  const [token, setToken] = useState(null);
  const [userId, setUserId] = useState(null);
  const userIsLoggedIn = !!token;

  const loginHandler = (token, userId) => {
    setToken(token);
    setUserId(userId);
    const expirationTime = new Date().getTime() + 300000;
    localStorage.setItem('token', token);
    localStorage.setItem('userId', userId);
    localStorage.setItem('expirationTime', expirationTime.toString());
  };

  const logoutHandler = () => {
    setToken(null);
    setUserId(null);
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('expirationTime');
  };

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    const storedUserId = localStorage.getItem('userId');
    const storedExpirationTime = localStorage.getItem('expirationTime');
    if (storedToken && storedUserId && storedExpirationTime) {
      const remainingTime = calculateRemainingTime(storedExpirationTime);
      if (remainingTime > 0) {
        setToken(storedToken);
        setUserId(storedUserId);
        const logoutTimer = setTimeout(logoutHandler, remainingTime);
        return () => {
          clearTimeout(logoutTimer);
        };
      } else {
        logoutHandler();
      }
    }
  }, []);

  const calculateRemainingTime = (expirationTime) => {
    const currentTime = new Date().getTime();
    const adjustedExpirationTime = parseInt(expirationTime);
    const remainingTime = adjustedExpirationTime - currentTime;
    return remainingTime;
  };

  const contextValue = {
    token: token,
    isLoggedIn: userIsLoggedIn,
    userId: userId,
    login: loginHandler,
    logout: logoutHandler,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {props.children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
